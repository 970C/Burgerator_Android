package Burgerator.Classes;

import java.net.URL;

/**
 * Wraps the information of restaurant entries extracted from YELP API AS JSON
 *
 */
public class RestaurantEntry {

    private float distance;
    private String name;
    private String address;
    private URL imageIcon;

    public RestaurantEntry(float distance, String name, String address, URL imageIcon){
        this.distance = distance;
        this.name = name;
        this.address = address;
        this.imageIcon = imageIcon;
    }

    public float getDistance() {
        return distance;
    }

    public void setDistance(float distance) {
        this.distance = distance;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public URL getImageIcon() {
        return imageIcon;
    }

    public void setImageIcon(URL imageIcon) {
        this.imageIcon = imageIcon;
    }
}
