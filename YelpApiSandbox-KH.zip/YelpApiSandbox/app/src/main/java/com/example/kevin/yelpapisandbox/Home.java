package com.example.kevin.yelpapisandbox;

import android.app.ListActivity;
import android.os.AsyncTask;
import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.support.v7.util.AsyncListUtil;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;

import com.beust.jcommander.JCommander;

import java.util.ArrayList;

import Burgerator.Classes.RestaurantEntry;


public class Home extends ListActivity {

    private TextView yelpOutput;
    private QueryThread simplePull;
    private ListView restaurantListView;
    //private ArrayAdapter<RestaurantEntry> listAdapter;
    private RestaurantEntryAdapter mAdapter;

    private class QueryThread extends AsyncTask<Void,Void,String>{
        @Override
        protected String doInBackground(Void... params) {

            // Creates a YelpAPI object that sets up connection
            YelpAPI testYelpAPI = new YelpAPI();

            return YelpAPI.main();
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //setContentView(R.layout.activity_home);

        // Create a new RestaurantEntryAdapter for this ListActivity's ListView
        mAdapter = new RestaurantEntryAdapter(getApplicationContext());

        getListView().setHeaderDividersEnabled(true);
        getListView().setDividerHeight(1);
        getListView().setAdapter(mAdapter);

        // Inflate headerView named restaurant test

        // Initialize List View
        //restaurantListView = (ListView)findViewById(R.id.restaurantListView);

        //Initialize restaurant(s)
        RestaurantEntry testRestaurant = new RestaurantEntry((float)2.3,"Yellow Taco",
                                                             "404 Not Found Lane",null);

        mAdapter.add(testRestaurant);
        // Initilize array of RestaurantEntry's
        ArrayList<RestaurantEntry> restaurants = new ArrayList<RestaurantEntry>();
        restaurants.add(testRestaurant);

        // Initialize adapter
        //////listAdapter = new ArrayAdapter<RestaurantEntry>(this,R.layout.restaurant_entry,restaurants);


        // Add items to adapter if you want to
            //

        //Set the ArrayAdapter to the ListView
        ///restaurantListView.setAdapter(listAdapter);

        // Run thread
        //simplePull = new QueryThread();
        //simplePull.execute();

    }

    @Override
    protected void onResume() {
        super.onResume();
        /*
        try {
            yelpOutput.setText(simplePull.get());
        }catch (Exception e){
            yelpOutput.setText(e.toString());
        }
        */
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_home, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
