package com.example.kevin.yelpapisandbox;

import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;

import com.beust.jcommander.JCommander;


public class Home extends ActionBarActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        String CONSUMER_KEY = "gP8tFaK3EUIXuYnVgiF3Eg";
        String CONSUMER_SECRET = "6mTmYvFwCjq_jxlR6vzgBUy1ENo";
        String TOKEN = "UA4FPch6l1HEBT9lqXNJTTadm632NkHA";
        String TOKEN_SECRET = "b1hrUcjSmR1vu1BdcJEQdluOWVQ";

        YelpAPI testYelpAPI = new YelpAPI(CONSUMER_KEY,CONSUMER_SECRET,TOKEN,TOKEN_SECRET);

        //YelpAPI.main();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_home, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
